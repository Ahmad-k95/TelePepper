using UnityEngine;
using System.Net;
using System.Net.Sockets;
using System.Text;

public class HeadSocketSender : MonoBehaviour
{
    [Header("Drag XR Origin > Camera Offset > Main Camera here")]
    public Transform xrCamera;

    public string ipAddress = "127.0.0.1"; // Python on same PC
    public int port = 5055;

    public float sendInterval = 0.01f;

    private UdpClient udpClient;
    private IPEndPoint endPoint;
    private float timer;

    void Start()
    {
        udpClient = new UdpClient();
        endPoint = new IPEndPoint(IPAddress.Parse(ipAddress), port);
    }

    void Update()
    {
        if (xrCamera == null)
        {
            Debug.LogWarning("xrCamera is not assigned.");
            return;
        }

        timer += Time.deltaTime;

        if (timer >= sendInterval)
        {
            timer = 0f;

            // Vector3 pos = xrCamera.position;
            Vector3 rot = xrCamera.rotation.eulerAngles;

            string message = rot.x + "," + rot.y;
            //  + "," + rot.z;
            //pos.x + "," + pos.y + "," + pos.z + "," +

            byte[] data = Encoding.UTF8.GetBytes(message);
            udpClient.Send(data, data.Length, endPoint);
        }
    }

    void OnApplicationQuit()
    {
        udpClient?.Close();
    }
}