using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using Ruccho.GraphicsCapture;
using UnityEngine;
//using UnityEngine.Diagnostics;
using UnityEngine.UI;

public class NativeDesktopFullscreen : MonoBehaviour
{
    private Capture capture;

    [Header("Components")]
    [SerializeField] private RawImage rawImage;

    [Header("Display / Immersion")]
    [SerializeField] private float defaultScale = 0.6f;
    [SerializeField] private float scale = 0.6f;

    [SerializeField] private float screenWidth = 1920f;
    [SerializeField] private float screenHeight = 1080f;

    [Header("Performance")]
    [SerializeField] private int targetFrameRate = 72;
    [SerializeField] private bool flipY = true;

    [Header("Global Keyboard Control")]
    [SerializeField] private float moveSpeed = 300f;
    [SerializeField] private float zoomSpeed = 0.5f;
    [SerializeField] private float minScale = 0.1f;
    [SerializeField] private float maxScale = 2.5f;

    private RenderTexture flippedTexture;
    private RectTransform rect;

    [DllImport("user32.dll")]
    private static extern short GetAsyncKeyState(int vKey);

    void Start()
    {
        Application.targetFrameRate = targetFrameRate;
        QualitySettings.vSyncCount = 0;

        if (rawImage == null)
        {
            Debug.LogError("RawImage is not assigned in the Inspector!");
            return;
        }

        rect = rawImage.rectTransform;
        scale = defaultScale;

        SetupRawImageRect();

        IEnumerable<ICaptureTarget> targets = Utils.GetTargets();

        foreach (var target in targets)
        {
            Debug.Log("[CaptureTarget] " + target.Description);
        }

        ICaptureTarget selectedTarget = targets.FirstOrDefault(t =>
            t.Description.ToLower().Contains("display") ||
            t.Description.ToLower().Contains("monitor") ||
            t.Description.ToLower().Contains("dell"));

        if (selectedTarget == null)
            selectedTarget = targets.FirstOrDefault();

        if (selectedTarget == null)
        {
            Debug.LogError("No capture target found.");
            return;
        }

        capture = new Capture(selectedTarget);
        capture.Start();

        Debug.Log("Capture started: " + selectedTarget.Description);
    }

    void SetupRawImageRect()
    {
        rect.anchorMin = new Vector2(0.5f, 0.5f);
        rect.anchorMax = new Vector2(0.5f, 0.5f);
        rect.pivot = new Vector2(0.5f, 0.5f);
        rect.anchoredPosition = Vector2.zero;

        ApplyScale();
    }

    void Update()
    {
        if (capture == null || rawImage == null)
            return;

        HandleKeyboardControls();

        Texture tex = capture.GetTexture();

        if (tex == null)
            return;

        if (!flipY)
        {
            rawImage.texture = tex;
            return;
        }

        if (flippedTexture == null ||
            flippedTexture.width != tex.width ||
            flippedTexture.height != tex.height)
        {
            if (flippedTexture != null)
                flippedTexture.Release();

            flippedTexture = new RenderTexture(tex.width, tex.height, 0);
            flippedTexture.filterMode = FilterMode.Bilinear;
            flippedTexture.useMipMap = false;
            flippedTexture.autoGenerateMips = false;
        }

        Graphics.Blit(
            tex,
            flippedTexture,
            new Vector2(1, -1),
            new Vector2(0, 1)
        );

        rawImage.texture = flippedTexture;
    }

    void HandleKeyboardControls()
    {
        Vector2 movement = Vector2.zero;

        if (GetAsyncKeyState(0x25) != 0) // Left Arrow
            movement.x -= moveSpeed * Time.deltaTime;

        if (GetAsyncKeyState(0x27) != 0) // Right Arrow
            movement.x += moveSpeed * Time.deltaTime;

        if (GetAsyncKeyState(0x26) != 0) // Up Arrow
            movement.y += moveSpeed * Time.deltaTime;

        if (GetAsyncKeyState(0x28) != 0) // Down Arrow
            movement.y -= moveSpeed * Time.deltaTime;

        rect.anchoredPosition += movement;

        if (GetAsyncKeyState(0x6B) != 0) // Numpad +
        {
            scale += zoomSpeed * Time.deltaTime;
            scale = Mathf.Clamp(scale, minScale, maxScale);
            ApplyScale();
        }

        if (GetAsyncKeyState(0x6D) != 0) // Numpad -
        {
            scale -= zoomSpeed * Time.deltaTime;
            scale = Mathf.Clamp(scale, minScale, maxScale);
            ApplyScale();
        }

        if (GetAsyncKeyState(0x52) != 0) // R
        {
            rect.anchoredPosition = Vector2.zero;
            scale = defaultScale;
            ApplyScale();
        }
    }

    void ApplyScale()
    {
        rect.sizeDelta = new Vector2(
            screenWidth * scale,
            screenHeight * scale
        );
    }

    void OnDestroy()
    {
        capture?.Dispose();

        if (flippedTexture != null)
            flippedTexture.Release();
    }
}