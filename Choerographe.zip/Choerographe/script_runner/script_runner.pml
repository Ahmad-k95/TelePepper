<?xml version="1.0" encoding="UTF-8" ?>
<Package name="script_runner" format_version="4">
    <Manifest src="manifest.xml" />
    <BehaviorDescriptions>
        <BehaviorDescription name="behavior" src="behavior_1" xar="behavior.xar" />
    </BehaviorDescriptions>
    <Dialogs />
    <Resources>
        <File name="Calibration" src="behavior_1/data/experiments/Calibration.txt" />
        <File name="seqA" src="behavior_1/data/experiments/seqA.txt" />
        <File name="seqA_i" src="behavior_1/data/experiments/seqA_i.txt" />
        <File name="seqA_r" src="behavior_1/data/experiments/seqA_r.txt" />
        <File name="seqB" src="behavior_1/data/experiments/seqB.txt" />
        <File name="seqB_i" src="behavior_1/data/experiments/seqB_i.txt" />
        <File name="seqB_r " src="behavior_1/data/experiments/seqB_r .txt" />
        <File name="seqC" src="behavior_1/data/experiments/seqC.txt" />
        <File name="seqC_i" src="behavior_1/data/experiments/seqC_i.txt" />
        <File name="seqC_r" src="behavior_1/data/experiments/seqC_r.txt" />
        <File name="seqD" src="behavior_1/data/experiments/seqD.txt" />
        <File name="seqD_i" src="behavior_1/data/experiments/seqD_i.txt" />
        <File name="seqD_r" src="behavior_1/data/experiments/seqD_r.txt" />
        <File name="seqE" src="behavior_1/data/experiments/seqE.txt" />
        <File name="seqE_i" src="behavior_1/data/experiments/seqE_i.txt" />
        <File name="seqE_r" src="behavior_1/data/experiments/seqE_r.txt" />
        <File name="seqF" src="behavior_1/data/experiments/seqF.txt" />
        <File name="seqF_i" src="behavior_1/data/experiments/seqF_i.txt" />
        <File name="seqF_r" src="behavior_1/data/experiments/seqF_r.txt" />
        <File name="seqG" src="behavior_1/data/experiments/seqG.txt" />
        <File name="seqG_i" src="behavior_1/data/experiments/seqG_i.txt" />
        <File name="seqG_r" src="behavior_1/data/experiments/seqG_r.txt" />
        <File name="seqH" src="behavior_1/data/experiments/seqH.txt" />
        <File name="seqH_i" src="behavior_1/data/experiments/seqH_i.txt" />
        <File name="seqH_r" src="behavior_1/data/experiments/seqH_r.txt" />
        <File name="seqI" src="behavior_1/data/experiments/seqI.txt" />
        <File name="seqI_i" src="behavior_1/data/experiments/seqI_i.txt" />
        <File name="seqI_r" src="behavior_1/data/experiments/seqI_r.txt" />
        <File name="seqJ" src="behavior_1/data/experiments/seqJ.txt" />
        <File name="seqJ_i" src="behavior_1/data/experiments/seqJ_i.txt" />
        <File name="seqJ_r" src="behavior_1/data/experiments/seqJ_r.txt" />
        <File name="test arduino" src="behavior_1/data/experiments/test arduino.txt" />
        <File name="motions_data" src="behavior_1/data/motions_data.txt" />
        <File name="postures_data" src="behavior_1/data/postures_data.txt" />
        <File name="test" src="behavior_1/data/experiments/test.txt" />
    </Resources>
    <Topics />
    <IgnoredPaths />
    <Translations auto-fill="en_US">
        <Translation name="translation_en_US" src="translations/translation_en_US.ts" language="en_US" />
    </Translations>
</Package>
