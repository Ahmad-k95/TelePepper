# -*- coding: utf-8 -*-
import socket
import math
import threading
import tempfile
import os
import time

from naoqi import ALProxy

try:
    from gtts import gTTS
    import pygame
    TTS_AVAILABLE = True
except ImportError:
    TTS_AVAILABLE = False

# ── Constantes serveur Choregraphe ───────────────────────────────────────────
CHOREO_HOST = "0.0.0.0"
CHOREO_PORT = 5000


class PepperHeadTracker(object):

    LIMITS = {
        "HeadYaw":   [-119.5, 119.5],
        "HeadPitch": [-40.5,  25.5],
    }

    def __init__(self, robot_ip, port=9559,
                 udp_ip="127.0.0.1", udp_port=5055,
                 gui_ref=None):
        self.robot_ip  = robot_ip
        self.port      = port
        self.udp_ip    = udp_ip
        self.udp_port  = udp_port
        self.gui_ref   = gui_ref      # référence à PepperGUI (pour send_message)

        self.motion  = None
        self.posture = None
        self.life    = None
        self.sock    = None

        self.tracking_enabled = False

        # Serveur Choregraphe (TCP)
        self._choreo_server_socket = None
        self._choreo_thread        = None
        self._choreo_running       = False

    # ── Maths ────────────────────────────────────────────────────────────────

    def normalize_angle(self, angle_str, reverse=False):
        angle = float(angle_str)
        if angle > 180:
            angle -= 360
        return -angle if reverse else angle

    def clamp(self, value, min_value, max_value):
        return max(min(value, max_value), min_value)

    # ── Connexion robot ───────────────────────────────────────────────────────

    def connect_robot(self):
        self.motion  = ALProxy("ALMotion",         self.robot_ip, self.port)
        self.posture = ALProxy("ALRobotPosture",   self.robot_ip, self.port)
        self.life    = ALProxy("ALAutonomousLife", self.robot_ip, self.port)

        if self.life.getState() != "disabled":
            self.life.setState("disabled")

        self.motion.setIdlePostureEnabled("Head", False)
        self.motion.setBreathEnabled("Head", False)
        self.motion.wakeUp()
        self.posture.goToPosture("StandInit", 0.5)

    # ── UDP head tracking ─────────────────────────────────────────────────────

    def setup_socket(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind((self.udp_ip, self.udp_port))
        self.sock.settimeout(1.0)

    def move_head(self, pitch_raw, yaw_raw):
        pitch_deg = self.normalize_angle(pitch_raw, reverse=False)
        yaw_deg   = self.normalize_angle(yaw_raw,   reverse=True)

        pitch_final = self.clamp(
            pitch_deg,
            self.LIMITS["HeadPitch"][0],
            self.LIMITS["HeadPitch"][1]
        )
        yaw_final = self.clamp(
            yaw_deg,
            self.LIMITS["HeadYaw"][0],
            self.LIMITS["HeadYaw"][1]
        )

        self.motion.setAngles(
            ["HeadYaw", "HeadPitch"],
            [math.radians(yaw_final), math.radians(pitch_final)],
            0.2
        )

    def run(self):
        """Boucle UDP — tournée dans un thread dédié par la GUI."""
        try:
            self.setup_socket()
            while getattr(self, "tracking_enabled", True):
                try:
                    data, addr = self.sock.recvfrom(1024)
                    message    = data.decode("utf-8")
                    parts      = message.split(",")

                    if len(parts) >= 2:
                        self.move_head(parts[0], parts[1])

                except socket.timeout:
                    continue

        except Exception as e:
            pass

        finally:
            try:
                if self.sock:
                    self.sock.close()
            except Exception:
                pass

    def stop(self):
        """Arrêt propre — ne touche PAS à la posture du robot."""
        self.tracking_enabled = False
        try:
            if getattr(self, "sock", None):
                self.sock.close()
        except Exception:
            pass

    # ── Serveur Choregraphe (TCP) ─────────────────────────────────────────────

    def start_choreo_server(self):
        """
        Démarre le serveur TCP Choregraphe dans un thread daemon.
        Appelé une seule fois lors de la connexion au robot.
        """
        if self._choreo_thread and self._choreo_thread.is_alive():
            return

        self._choreo_running = True

        self._choreo_thread = threading.Thread(
            target=self._choreo_server_loop,
            name="ChoreoServer"
        )
        self._choreo_thread.daemon = True
        self._choreo_thread.start()

    def stop_choreo_server(self):
        """Arrête proprement le serveur TCP Choregraphe."""
        self._choreo_running = False

        try:
            if self._choreo_server_socket:
                self._choreo_server_socket.close()
        except Exception:
            pass

    def _choreo_server_loop(self):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        try:
            srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            srv.bind((CHOREO_HOST, CHOREO_PORT))
            srv.listen(5)
            srv.settimeout(1.0)   # permet de checker _choreo_running régulièrement
            self._choreo_server_socket = srv

            while self._choreo_running:
                try:
                    conn, addr = srv.accept()
                except socket.timeout:
                    continue
                except Exception:
                    break

                # Chaque connexion dans son propre thread
                t = threading.Thread(
                    target=self._choreo_handle_conn,
                    args=(conn, addr)
                )
                t.daemon = True
                t.start()

        except Exception as e:
            pass

        finally:
            try:
                srv.close()
            except Exception:
                pass

    def _choreo_handle_conn(self, conn, addr):
        try:
            data = conn.recv(1024)
            if data:
                message = data.decode("utf-8").strip()
                self._choreo_handle_message(message)
        except Exception as e:
            pass
        finally:
            conn.close()

    def _choreo_handle_message(self, message):
        pass

        if not message.startswith("c:"):
            return

        text = message[2:].strip()

        if not text:
            return

        if "trigger" in text.lower():
            t = threading.Thread(target=self._trig_arduino)
        else:
            t = threading.Thread(target=self._say_pc, args=(text,))

        t.daemon = True
        t.start()

    # ── Actions Choregraphe ───────────────────────────────────────────────────

    def _say_pc(self, text):
        if not TTS_AVAILABLE:
            return

        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as fp:
                temp_path = fp.name

            tts = gTTS(text=text, lang="fr")
            tts.save(temp_path)
            self._play_audio(temp_path)

        except Exception as e:
            pass

    @staticmethod
    def _play_audio(path):
        try:
            pygame.mixer.init()
            pygame.mixer.music.load(path)
            pygame.mixer.music.play()

            while pygame.mixer.music.get_busy():
                time.sleep(0.1)

            pygame.mixer.music.unload()

        except Exception as e:
            pass

        finally:
            try:
                os.remove(path)
            except Exception:
                pass

    def _trig_arduino(self):
        """
        Envoie un trigger à l'Arduino via la GUI si disponible,
        sinon affiche un log.
        """
        if self.gui_ref is not None:
            sent = self.gui_ref.send_message("1")
