# -*- coding: utf-8 -*-
"""
Pepper Robot Control GUI
Python 2.7 / Tkinter compatible
"""

import threading
import time

try:
    import tkinter as tk
    from tkinter import messagebox
except ImportError:
    import Tkinter as tk
    import tkMessageBox as messagebox

try:
    import cv2
    from PIL import Image, ImageTk
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False

try:
    import serial
    import serial.tools.list_ports
    SERIAL_AVAILABLE = True
except ImportError:
    SERIAL_AVAILABLE = False


BG_DARK      = "#0d0f14"
BG_PANEL     = "#13161e"
BG_CARD      = "#1a1e2a"
BG_CARD2     = "#1f2435"
ACCENT       = "#00c8ff"
ACCENT2      = "#0077ff"
SUCCESS      = "#00e676"
DANGER       = "#ff3b5c"
WARNING      = "#ffc107"
TEXT_PRIMARY = "#e8ecf4"
TEXT_MUTED   = "#6b7592"
BORDER       = "#252a3a"
BTN_ACTIVE   = "#0a3d52"

FONT_LABEL = ("Courier New", 9)
FONT_MONO  = ("Courier New", 9)
FONT_SMALL = ("Courier New", 8)
FONT_BTN   = ("Courier New", 9, "bold")
FONT_HEAD  = ("Courier New", 11, "bold")

VIDEO_RESOLUTION = 2
VIDEO_FPS = 30


def styled_frame(parent, bg=BG_CARD, bd=0, relief=tk.FLAT, **kw):
    return tk.Frame(parent, bg=bg, bd=bd, relief=relief, **kw)


def styled_label(parent, text="", fg=TEXT_PRIMARY, bg=BG_CARD,
                 font=FONT_LABEL, anchor="w", **kw):
    return tk.Label(parent, text=text, fg=fg, bg=bg,
                    font=font, anchor=anchor, **kw)


def styled_button(parent, text="", command=None, color=ACCENT2,
                  fg=TEXT_PRIMARY, width=16, **kw):
    btn = tk.Button(
        parent, text=text, command=command,
        bg=color, fg=fg, font=FONT_BTN,
        activebackground=BTN_ACTIVE, activeforeground=ACCENT,
        relief=tk.FLAT, bd=0, cursor="hand2",
        width=width, pady=5, **kw
    )

    def on_enter(e):
        if str(btn["state"]) != "disabled":
            btn.config(bg=BTN_ACTIVE)

    def on_leave(e):
        if str(btn["state"]) != "disabled":
            btn.config(bg=color)

    btn.bind("<Enter>", on_enter)
    btn.bind("<Leave>", on_leave)
    return btn


def section_header(parent, text, bg=BG_CARD):
    f = styled_frame(parent, bg=bg)
    tk.Frame(f, bg=ACCENT, width=3).pack(side=tk.LEFT, fill=tk.Y, padx=(0, 8))
    styled_label(f, text=text.upper(), fg=ACCENT,
                 bg=bg, font=FONT_HEAD).pack(side=tk.LEFT)
    return f


def status_dot(parent, bg_parent=BG_CARD):
    c = tk.Canvas(parent, width=12, height=12, bg=bg_parent,
                  highlightthickness=0)
    oval = c.create_oval(2, 2, 10, 10, fill=DANGER, outline="")
    return c, oval


class FullscreenVideoWindow(tk.Toplevel):
    def __init__(self, parent, gui_ref):
        tk.Toplevel.__init__(self, parent)
        self.gui_ref = gui_ref

        self.configure(bg="black")
        self.overrideredirect(True)
        self.attributes("-topmost", True)

        self.sw = self.winfo_screenwidth()
        self.sh = self.winfo_screenheight()
        self.geometry("{}x{}+0+0".format(self.sw, self.sh))

        self.canvas = tk.Canvas(self, bg="black", highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True)

        self._photo = None
        self._image_id = None
        self._last_seen_id = -1
        self._closed = False

        self.bind("<Escape>", lambda e: self._close())
        self.bind("<q>", lambda e: self._close())
        self.bind("<Q>", lambda e: self._close())
        self.focus_force()

        self._poll()

    def _poll(self):
        if self._closed:
            return

        frame = None
        frame_id = None

        with self.gui_ref._latest_frame_lock:
            frame = self.gui_ref._latest_frame
            frame_id = self.gui_ref._latest_frame_id

        if frame is not None and frame_id != self._last_seen_id:
            self._last_seen_id = frame_id
            self._display(frame)

        self.after(1, self._poll)

    def _display(self, frame_rgb):
        try:
            h, w = frame_rgb.shape[:2]

            scale = min(self.sw / float(w), self.sh / float(h))
            nw, nh = int(w * scale), int(h * scale)

            resized = cv2.resize(
                frame_rgb,
                (nw, nh),
                interpolation=cv2.INTER_LINEAR
            )

            img = Image.fromarray(resized)
            photo = ImageTk.PhotoImage(image=img)

            if self._image_id is None:
                self._image_id = self.canvas.create_image(
                    self.sw // 2,
                    self.sh // 2,
                    image=photo,
                    anchor=tk.CENTER
                )
            else:
                self.canvas.itemconfig(self._image_id, image=photo)

            self._photo = photo

        except Exception:
            pass

    def _close(self):
        self._closed = True

        try:
            self.gui_ref.fullscreen_active = False
            self.gui_ref.fullscreen_var.set(False)
            self.gui_ref.deiconify()
        except Exception:
            pass

        self.destroy()


class PepperGUI(tk.Tk):

    def __init__(self):
        tk.Tk.__init__(self)

        self.title("Pepper Robot Control Center")
        self.configure(bg=BG_DARK)
        self.minsize(1400, 860)
        self.resizable(True, True)

        self.connected = False
        self.robot_ip = tk.StringVar(value="169.254.218.53")
        self.robot_port = tk.IntVar(value=9559)
        self.cam_index = tk.IntVar(value=1)
        self.fullscreen_var = tk.BooleanVar(value=False)

        self.tracker = None
        self.vision = None
        self.behavior_manager = None
        self.posture = None

        self.track_thread = None
        self.vision_thread = None

        self._latest_frame = None
        self._latest_frame_id = 0
        self._latest_frame_lock = threading.Lock()

        self._fullscreen_window = None
        self.fullscreen_active = False

        # Track whether the robot has been put to sleep via this GUI
        self._robot_is_sleeping = False

        # Arduino serial state
        self._serial_conn  = None
        self._serial_port  = tk.StringVar(value="")

        self._build_ui()
        self._poll_frame()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_ui(self):
        self._build_titlebar()

        body = styled_frame(self, bg=BG_DARK)
        body.pack(fill=tk.BOTH, expand=True, padx=12, pady=(0, 12))

        left = styled_frame(body, bg=BG_DARK, width=280)
        left.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        left.pack_propagate(False)

        self._build_connection_panel(left)
        self._build_control_panel(left)
        self._build_arduino_panel(left)

        right = styled_frame(body, bg=BG_DARK)
        right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self._build_vision_panel(right)

    def _build_titlebar(self):
        bar = styled_frame(self, bg=BG_PANEL, height=48)
        bar.pack(fill=tk.X)
        bar.pack_propagate(False)

        styled_label(
            bar,
            text="PEPPER  CONTROL  CENTER",
            fg=ACCENT,
            bg=BG_PANEL,
            font=("Courier New", 13, "bold")
        ).pack(side=tk.LEFT, padx=20)

        self.clock_lbl = styled_label(
            bar,
            text="",
            fg=TEXT_MUTED,
            bg=BG_PANEL,
            font=FONT_SMALL
        )
        self.clock_lbl.pack(side=tk.RIGHT, padx=20)

        self._tick_clock()

    def _tick_clock(self):
        import datetime
        self.clock_lbl.config(
            text=datetime.datetime.now().strftime("%H:%M:%S   %Y-%m-%d")
        )
        self.after(1000, self._tick_clock)

    def _build_connection_panel(self, parent):
        card = styled_frame(parent, bg=BG_CARD)
        card.pack(fill=tk.X, pady=(0, 8))

        section_header(card, "connection").pack(
            fill=tk.X, padx=12, pady=(12, 8)
        )

        inner = styled_frame(card, bg=BG_CARD)
        inner.pack(fill=tk.X, padx=12, pady=(0, 12))

        styled_label(
            inner,
            text="IP ADDRESS",
            fg=TEXT_MUTED,
            bg=BG_CARD,
            font=FONT_SMALL
        ).grid(row=0, column=0, sticky="w", pady=(0, 2))

        tk.Entry(
            inner,
            textvariable=self.robot_ip,
            bg=BG_CARD2,
            fg=TEXT_PRIMARY,
            insertbackground=ACCENT,
            font=FONT_MONO,
            relief=tk.FLAT,
            bd=1,
            highlightbackground=BORDER,
            highlightcolor=ACCENT,
            highlightthickness=1,
            width=22
        ).grid(row=1, column=0, columnspan=2, sticky="ew",
               pady=(0, 8), ipady=5)

        styled_label(
            inner,
            text="PORT",
            fg=TEXT_MUTED,
            bg=BG_CARD,
            font=FONT_SMALL
        ).grid(row=2, column=0, sticky="w", pady=(0, 2))

        tk.Entry(
            inner,
            textvariable=self.robot_port,
            bg=BG_CARD2,
            fg=TEXT_PRIMARY,
            insertbackground=ACCENT,
            font=FONT_MONO,
            relief=tk.FLAT,
            bd=1,
            highlightbackground=BORDER,
            highlightcolor=ACCENT,
            highlightthickness=1,
            width=10
        ).grid(row=3, column=0, sticky="w", pady=(0, 8), ipady=5)

        status_row = styled_frame(inner, bg=BG_CARD)
        status_row.grid(row=4, column=0, columnspan=2,
                        sticky="ew", pady=(0, 10))

        self.dot_canvas, self.dot_oval = status_dot(status_row, BG_CARD)
        self.dot_canvas.pack(side=tk.LEFT, padx=(0, 6))

        self.conn_label = styled_label(
            status_row,
            text="DISCONNECTED",
            fg=DANGER,
            bg=BG_CARD,
            font=FONT_BTN
        )
        self.conn_label.pack(side=tk.LEFT)

        self.connect_btn = styled_button(
            inner,
            text="CONNECT",
            command=self._toggle_connect,
            color=ACCENT2,
            width=24
        )
        self.connect_btn.grid(row=5, column=0, columnspan=2,
                              sticky="ew", pady=(0, 4))

        inner.columnconfigure(0, weight=1)

    def _build_control_panel(self, parent):
        card = styled_frame(parent, bg=BG_CARD)
        card.pack(fill=tk.X)

        section_header(card, "robot control").pack(
            fill=tk.X, padx=12, pady=(12, 10)
        )

        inner = styled_frame(card, bg=BG_CARD)
        inner.pack(fill=tk.X, padx=12)

        row1 = styled_frame(inner, bg=BG_CARD)
        row1.pack(fill=tk.X, pady=(0, 6))

        # Center container
        button_container = styled_frame(row1, bg=BG_CARD)
        button_container.pack(anchor="center")

        self.wake_btn = styled_button(
            button_container,
            text="WAKE UP",
            command=self._wake_up,
            color="#0d5c3b",
            width=8
        )
        self.wake_btn.pack(side=tk.LEFT, padx=(0, 20))

        self.sleep_btn = styled_button(
            button_container,
            text="SLEEP",
            command=self._sleep,
            color="#3d2a0a",
            width=8
        )
        self.sleep_btn.pack(side=tk.LEFT, padx=(0, 20))

        self.stand_init_btn = styled_button(
            button_container,
            text="STAND INIT",
            command=self._stand_init,
            color="#1a4d7a",
            width=10
        )
        self.stand_init_btn.pack(side=tk.LEFT)

        tk.Frame(inner, bg=BORDER, height=1).pack(fill=tk.X, pady=10)

        life_hdr = styled_frame(inner, bg=BG_CARD)
        life_hdr.pack(fill=tk.X, pady=(0, 6))

        styled_label(
            life_hdr,
            text="AUTONOMOUS LIFE",
            fg=TEXT_MUTED,
            bg=BG_CARD,
            font=FONT_SMALL
        ).pack(side=tk.LEFT)

        self.life_dot, self.life_oval = status_dot(life_hdr, BG_CARD)
        self.life_dot.pack(side=tk.RIGHT)

        self.life_lbl = styled_label(
            inner,
            text="STATE: UNKNOWN",
            fg=WARNING,
            bg=BG_CARD,
            font=FONT_SMALL
        )
        self.life_lbl.pack(anchor="w", pady=(0, 6))

        self.life_btn = styled_button(
            inner,
            text="ACTIVATE / DEACTIVATE LIFE",
            command=self._toggle_autonomous_life,
            color="#2a1d50",
            width=24
        )
        self.life_btn.pack(fill=tk.X, pady=(0, 6))

        tk.Frame(inner, bg=BORDER, height=1).pack(fill=tk.X, pady=10)

        styled_label(
            inner,
            text="HEAD TRACKING",
            fg=TEXT_MUTED,
            bg=BG_CARD,
            font=FONT_SMALL
        ).pack(anchor="w", pady=(0, 6))

        self.track_var = tk.BooleanVar(value=False)

        track_row = styled_frame(inner, bg=BG_CARD)
        track_row.pack(fill=tk.X)

        for txt, val in [("Disable", False), ("Enable UDP", True)]:
            tk.Radiobutton(
                track_row,
                text=txt,
                variable=self.track_var,
                value=val,
                command=self._toggle_tracking,
                bg=BG_CARD,
                fg=TEXT_PRIMARY,
                selectcolor=BG_CARD2,
                activebackground=BG_CARD,
                activeforeground=ACCENT,
                font=FONT_LABEL
            ).pack(side=tk.LEFT, padx=(0, 12))

        self.track_status = styled_label(
            inner,
            text="[ offline ]",
            fg=DANGER,
            bg=BG_CARD,
            font=FONT_SMALL
        )
        self.track_status.pack(anchor="w", pady=(6, 15))

    def _build_arduino_panel(self, parent):
        card = styled_frame(parent, bg=BG_CARD)
        card.pack(fill=tk.X, pady=(8, 0))

        section_header(card, "arduino serial").pack(
            fill=tk.X, padx=12, pady=(12, 8)
        )

        inner = styled_frame(card, bg=BG_CARD)
        inner.pack(fill=tk.X, padx=12, pady=(0, 12))

        styled_label(
            inner,
            text="SERIAL PORT",
            fg=TEXT_MUTED,
            bg=BG_CARD,
            font=FONT_SMALL
        ).pack(anchor="w", pady=(0, 4))

        port_row = styled_frame(inner, bg=BG_CARD)
        port_row.pack(fill=tk.X, pady=(0, 8))

        initial_ports = self._list_serial_ports()
        if not initial_ports:
            initial_ports = ["(none)"]
        self._serial_port.set(initial_ports[0])

        self._port_menu = tk.OptionMenu(
            port_row,
            self._serial_port,
            *initial_ports
        )
        self._port_menu.config(
            bg=BG_CARD2,
            fg=TEXT_PRIMARY,
            font=FONT_MONO,
            activebackground=BTN_ACTIVE,
            activeforeground=ACCENT,
            highlightthickness=0,
            relief=tk.FLAT,
            bd=0,
            width=16
        )
        self._port_menu["menu"].config(
            bg=BG_CARD2,
            fg=TEXT_PRIMARY,
            font=FONT_MONO,
            activebackground=BTN_ACTIVE
        )
        self._port_menu.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 6))

        styled_button(
            port_row,
            text="REFRESH",
            command=self._refresh_serial_ports,
            color="#1a2d3d",
            width=9
        ).pack(side=tk.LEFT)

        styled_label(
            inner,
            text="BAUD RATE",
            fg=TEXT_MUTED,
            bg=BG_CARD,
            font=FONT_SMALL
        ).pack(anchor="w", pady=(0, 4))

        self._baud_var = tk.StringVar(value="9600")
        baud_rates = ["1200", "9600", "19200", "38400", "57600", "115200"]

        baud_menu = tk.OptionMenu(inner, self._baud_var, *baud_rates)
        baud_menu.config(
            bg=BG_CARD2,
            fg=TEXT_PRIMARY,
            font=FONT_MONO,
            activebackground=BTN_ACTIVE,
            activeforeground=ACCENT,
            highlightthickness=0,
            relief=tk.FLAT,
            bd=0,
            width=16
        )
        baud_menu["menu"].config(
            bg=BG_CARD2,
            fg=TEXT_PRIMARY,
            font=FONT_MONO,
            activebackground=BTN_ACTIVE
        )
        baud_menu.pack(fill=tk.X, pady=(0, 10))

        status_row = styled_frame(inner, bg=BG_CARD)
        status_row.pack(fill=tk.X, pady=(0, 8))

        self._ard_dot_canvas, self._ard_dot_oval = status_dot(status_row, BG_CARD)
        self._ard_dot_canvas.pack(side=tk.LEFT, padx=(0, 6))

        self._ard_conn_label = styled_label(
            status_row,
            text="DISCONNECTED",
            fg=DANGER,
            bg=BG_CARD,
            font=FONT_BTN
        )
        self._ard_conn_label.pack(side=tk.LEFT)

        self._ard_connect_btn = styled_button(
            inner,
            text="CONNECT ARDUINO",
            command=self._toggle_arduino,
            color=ACCENT2,
            width=24
        )
        self._ard_connect_btn.pack(fill=tk.X)

    # ── Arduino helpers ──────────────────────────────────────────────────────

    def _list_serial_ports(self):
        if not SERIAL_AVAILABLE:
            return []
        return [p.device for p in serial.tools.list_ports.comports()]

    def _refresh_serial_ports(self):
        ports = self._list_serial_ports()
        if not ports:
            ports = ["(none)"]

        menu = self._port_menu["menu"]
        menu.delete(0, "end")

        for port in ports:
            menu.add_command(
                label=port,
                command=lambda p=port: self._serial_port.set(p)
            )

        if self._serial_port.get() not in ports:
            self._serial_port.set(ports[0])

    def _toggle_arduino(self):
        if self._serial_conn and self._serial_conn.is_open:
            try:
                self._serial_conn.close()
            except Exception:
                pass
            self._serial_conn = None

            self._ard_dot_canvas.itemconfig(self._ard_dot_oval, fill=DANGER)
            self._ard_conn_label.config(text="DISCONNECTED", fg=DANGER)
            self._ard_connect_btn.config(text="CONNECT ARDUINO", bg=ACCENT2)
            return

        if not SERIAL_AVAILABLE:
            messagebox.showerror(
                "Serial Unavailable",
                "pyserial is not installed.\n\n"
                "Install it with:\n  pip install pyserial"
            )
            return

        port = self._serial_port.get()
        if not port or port == "(none)":
            messagebox.showwarning(
                "No Port Selected",
                "Please select a valid serial port before connecting."
            )
            return

        try:
            baud = int(self._baud_var.get())
        except ValueError:
            baud = 9600

        self._ard_connect_btn.config(text="CONNECTING...", state=tk.DISABLED)
        self.update()

        def do_connect():
            try:
                conn = serial.Serial(port, baudrate=baud, timeout=1)
                time.sleep(2)
                self._serial_conn = conn
                self.after(0, self._on_arduino_connected)
            except Exception as e:
                self.after(0, lambda: self._on_arduino_connect_failed(str(e)))

        t = threading.Thread(target=do_connect)
        t.daemon = True
        t.start()

    def _on_arduino_connected(self):
        self._ard_dot_canvas.itemconfig(self._ard_dot_oval, fill=SUCCESS)
        self._ard_conn_label.config(text="CONNECTED", fg=SUCCESS)
        self._ard_connect_btn.config(
            text="DISCONNECT ARDUINO",
            state=tk.NORMAL,
            bg=DANGER
        )

    def _on_arduino_connect_failed(self, msg):
        self._ard_connect_btn.config(
            text="CONNECT ARDUINO",
            state=tk.NORMAL,
            bg=ACCENT2
        )
        messagebox.showerror(
            "Arduino Connection Failed",
            "Could not open serial port:\n\n" + msg
        )

    def send_message(self, message):
        if self._serial_conn is None or not self._serial_conn.is_open:
            return False

        try:
            payload = (message).encode("utf-8")
            self._serial_conn.write(payload)
            return True
        except Exception as e:
            return False

    # ── Vision panel ─────────────────────────────────────────────────────────

    def _build_vision_panel(self, parent):
        card = styled_frame(parent, bg=BG_CARD)
        card.pack(fill=tk.BOTH, expand=True)

        hdr = styled_frame(card, bg=BG_CARD)
        hdr.pack(fill=tk.X, padx=12, pady=(12, 8))

        section_header(hdr, "vision").pack(side=tk.LEFT)

        ctrl = styled_frame(hdr, bg=BG_CARD)
        ctrl.pack(side=tk.RIGHT)

        self.cam_status_lbl = styled_label(
            ctrl,
            text="CAM: BOTTOM",
            fg=ACCENT,
            bg=BG_CARD,
            font=FONT_SMALL
        )
        self.cam_status_lbl.pack(side=tk.LEFT, padx=(0, 12))

        styled_button(
            ctrl,
            text="SWITCH CAM",
            command=self._switch_camera,
            color="#1a2d3d",
            width=14
        ).pack(side=tk.LEFT)

        self.canvas = tk.Canvas(
            card,
            bg="#090b10",
            highlightbackground=BORDER,
            highlightthickness=1
        )
        self.canvas.pack(fill=tk.BOTH, expand=True, padx=12, pady=(0, 8))
        self.canvas.bind("<Configure>", lambda e: self._draw_placeholder())
        self._draw_placeholder()

        bot = styled_frame(card, bg=BG_CARD)
        bot.pack(fill=tk.X, padx=12, pady=(0, 12))

        fs_frame = styled_frame(bot, bg=BG_CARD)
        fs_frame.pack(side=tk.LEFT)

        styled_label(
            fs_frame,
            text="DISPLAY MODE:",
            fg=TEXT_MUTED,
            bg=BG_CARD,
            font=FONT_SMALL
        ).pack(side=tk.LEFT, padx=(0, 8))

        for txt, val in [("Windowed", False), ("Fullscreen", True)]:
            tk.Radiobutton(
                fs_frame,
                text=txt,
                variable=self.fullscreen_var,
                value=val,
                command=self._handle_fullscreen,
                bg=BG_CARD,
                fg=TEXT_PRIMARY,
                selectcolor=BG_CARD2,
                activebackground=BG_CARD,
                activeforeground=ACCENT,
                font=FONT_LABEL
            ).pack(side=tk.LEFT, padx=(0, 10))

        self.fps_lbl = styled_label(
            bot,
            text="FPS: --",
            fg=TEXT_MUTED,
            bg=BG_CARD,
            font=FONT_SMALL
        )
        self.fps_lbl.pack(side=tk.RIGHT)

        self._fps_count = 0
        self._fps_time = time.time()

    def _draw_placeholder(self):
        try:
            self.canvas.delete("placeholder")

            w = self.canvas.winfo_width()
            h = self.canvas.winfo_height()

            if w < 5:
                w = 640
            if h < 5:
                h = 420

            cx = w // 2
            cy = h // 2

            self.canvas.create_rectangle(
                0, 0, w, h,
                fill="#090b10",
                outline="",
                tags="placeholder"
            )

            self.canvas.create_text(
                cx, cy,
                text="[ NO SIGNAL ]",
                fill=TEXT_MUTED,
                font=("Courier New", 20, "bold"),
                anchor=tk.CENTER,
                tags="placeholder"
            )

            self.canvas.create_text(
                cx, cy + 36,
                text="Connect to robot and start vision",
                fill=BORDER,
                font=FONT_SMALL,
                anchor=tk.CENTER,
                tags="placeholder"
            )

        except Exception:
            pass

    # ── Connection ────────────────────────────────────────────────────────────

    def _toggle_connect(self):
        if not self.connected:
            self._connect()
        else:
            self._disconnect()

    def _connect(self):
        ip = self.robot_ip.get().strip()
        port = self.robot_port.get()

        self.connect_btn.config(text="CONNECTING...", state=tk.DISABLED)
        self.update()

        def do_connect():
            try:
                from naoqi import ALProxy
                from tracking import PepperHeadTracker
                from vision import PepperVision

                self.tracker = PepperHeadTracker(ip, port, gui_ref=self)
                self.tracker.connect_robot()

                try:
                    self.behavior_manager = ALProxy(
                        "ALBehaviorManager", ip, port
                    )
                    self.posture = ALProxy(
                        "ALRobotPosture", ip, port
                    )
                    self.behavior_manager.stopAllBehaviors()
                except Exception as e:
                    pass

                self.vision = PepperVision(
                    ip, port,
                    camera_index=self.cam_index.get(),
                    frame_store=self
                )

                self.after(0, self._on_connected)

            except Exception as e:
                self.after(0, lambda: self._on_connect_failed(str(e)))

        t = threading.Thread(target=do_connect)
        t.daemon = True
        t.start()

    def _on_connected(self):
        self.connected = True

        self.connect_btn.config(
            text="DISCONNECT",
            state=tk.NORMAL,
            bg=DANGER
        )

        self.dot_canvas.itemconfig(self.dot_oval, fill=SUCCESS)
        self.conn_label.config(text="CONNECTED", fg=SUCCESS)

        self.vision_thread = threading.Thread(target=self.vision.run_headless)
        self.vision_thread.daemon = True
        self.vision_thread.start()
        self.tracker.start_choreo_server()

        self._refresh_life_state_async()

    def _on_connect_failed(self, msg):
        self.connect_btn.config(text="CONNECT", state=tk.NORMAL, bg=ACCENT2)
        messagebox.showerror(
            "Connection Failed",
            "Could not connect to robot:\n\n" + msg
        )

    def _disconnect(self):
        """
        Disconnect from the robot.

        If the robot was put to sleep via this GUI (_robot_is_sleeping=True),
        we skip stopAllBehaviors() because that call can trigger an implicit
        wakeUp on some NaoQi versions, and we let the robot stay in rest
        posture after the TCP connection is dropped.
        """
        try:
            if self.vision:
                self.vision.stop()
        except Exception:
            pass

        try:
            if self.tracker:
                # Only stop behaviors when the robot is NOT sleeping.
                # stopAllBehaviors() can issue an implicit wakeUp internally.
                if self.behavior_manager and not self._robot_is_sleeping:
                    try:
                        self.behavior_manager.stopAllBehaviors()
                    except Exception as e:
                        pass

                self.tracker.stop_choreo_server()
                self.tracker.stop()
        except Exception:
            pass

        # Reset state flags
        self._robot_is_sleeping = False
        self.connected = False
        self.tracker = None
        self.vision = None
        self.behavior_manager = None
        self.posture = None

        with self._latest_frame_lock:
            self._latest_frame = None

        self.connect_btn.config(text="CONNECT", state=tk.NORMAL, bg=ACCENT2)
        self.dot_canvas.itemconfig(self.dot_oval, fill=DANGER)
        self.conn_label.config(text="DISCONNECTED", fg=DANGER)
        self.life_lbl.config(text="STATE: UNKNOWN", fg=WARNING)
        self.life_dot.itemconfig(self.life_oval, fill=WARNING)
        self.track_status.config(text="[ offline ]", fg=DANGER)

        self._draw_placeholder()

    def _require_connection(self, action="This action"):
        if not self.connected or self.tracker is None:
            messagebox.showwarning(
                "Not Connected",
                "{} requires an active robot connection.".format(action)
            )
            return False
        return True

    def _run_async(self, button, running_text, func):
        old_text = button["text"]
        old_state = button["state"]

        button.config(text=running_text, state=tk.DISABLED)

        def worker():
            try:
                func()
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error", str(e)))
            finally:
                self.after(
                    0,
                    lambda: button.config(text=old_text, state=old_state)
                )

        t = threading.Thread(target=worker)
        t.daemon = True
        t.start()

    # ── Robot actions ─────────────────────────────────────────────────────────

    def _wake_up(self):
        if not self._require_connection("Wake Up"):
            return

        def action():
            self.tracker.motion.wakeUp()
            self._robot_is_sleeping = False

        self._run_async(self.wake_btn, "WORKING...", action)

    def _sleep(self):
        if not self._require_connection("Sleep"):
            return

        def action():
            self.tracker.motion.rest()
            self._robot_is_sleeping = True

        self._run_async(self.sleep_btn, "WORKING...", action)

    def _stand_init(self):
        if not self._require_connection("Stand Init"):
            return

        def action():
            # StandInit needs the robot motors/stiffness enabled.
            self.tracker.motion.wakeUp()

            if self.posture is not None:
                self.posture.goToPosture("StandInit", 0.5)
            else:
                # Fallback if ALRobotPosture proxy was not created.
                from naoqi import ALProxy
                posture = ALProxy(
                    "ALRobotPosture",
                    self.robot_ip.get().strip(),
                    self.robot_port.get()
                )
                posture.goToPosture("StandInit", 0.5)

            self._robot_is_sleeping = False

        self._run_async(self.stand_init_btn, "WORKING...", action)

    def _refresh_life_state_async(self):
        def worker():
            try:
                state = self.tracker.life.getState()
                self.after(0, lambda: self._update_life_ui(state))
            except Exception:
                pass

        t = threading.Thread(target=worker)
        t.daemon = True
        t.start()

    def _update_life_ui(self, state):
        if state == "disabled":
            self.life_lbl.config(text="STATE: DISABLED", fg=WARNING)
            self.life_dot.itemconfig(self.life_oval, fill=WARNING)
            self.life_btn.config(text="ACTIVATE LIFE")
        else:
            self.life_lbl.config(
                text="STATE: {}".format(state.upper()), fg=SUCCESS
            )
            self.life_dot.itemconfig(self.life_oval, fill=SUCCESS)
            self.life_btn.config(text="DEACTIVATE LIFE")

    def _toggle_autonomous_life(self):
        if not self._require_connection("Autonomous Life"):
            return

        self.life_btn.config(text="WORKING...", state=tk.DISABLED)

        def worker():
            try:
                current = self.tracker.life.getState()

                if current == "disabled":
                    self.tracker.life.setState("solitary")
                    new_state = "solitary"
                else:
                    self.tracker.life.setState("disabled")
                    new_state = "disabled"

                self.after(0, lambda: self._update_life_ui(new_state))

            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error", str(e)))

            finally:
                self.after(0, lambda: self.life_btn.config(state=tk.NORMAL))

        t = threading.Thread(target=worker)
        t.daemon = True
        t.start()

    def _toggle_tracking(self):
        if not self.track_var.get():
            if self.tracker:
                self.tracker.tracking_enabled = False
            self.track_status.config(text="[ offline ]", fg=DANGER)
            return

        if not self._require_connection("Head Tracking"):
            self.track_var.set(False)
            return

        self.tracker.tracking_enabled = True

        if self.track_thread is None or not self.track_thread.is_alive():
            self.track_thread = threading.Thread(target=self.tracker.run)
            self.track_thread.daemon = True
            self.track_thread.start()

        self.track_status.config(text="[ tracking ]", fg=SUCCESS)

    def _switch_camera(self):
        if not self._require_connection("Camera Switch"):
            return

        new_idx = 0 if self.cam_index.get() == 1 else 1
        self.cam_index.set(new_idx)

        label = "TOP" if new_idx == 0 else "BOTTOM"
        self.cam_status_lbl.config(text="CAM: {}".format(label))

        try:
            self.vision.switch_camera(new_idx)
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _handle_fullscreen(self):
        if not self.fullscreen_var.get():
            return

        if not self._require_connection("Fullscreen"):
            self.fullscreen_var.set(False)
            return

        self.fullscreen_active = True
        self.withdraw()

        self._fullscreen_window = FullscreenVideoWindow(self, self)
        self._fullscreen_window.protocol(
            "WM_DELETE_WINDOW",
            self._fullscreen_window._close
        )

    def push_frame(self, frame_rgb):
        with self._latest_frame_lock:
            self._latest_frame = frame_rgb
            self._latest_frame_id += 1

    def _poll_frame(self):
        if self.fullscreen_active:
            self.after(16, self._poll_frame)
            return

        frame = None

        with self._latest_frame_lock:
            frame = self._latest_frame

        if frame is not None:
            self._display_frame(frame)

        self.after(16, self._poll_frame)

    def _display_frame(self, frame_rgb):
        if not CV2_AVAILABLE:
            return

        try:
            cw = self.canvas.winfo_width()
            ch = self.canvas.winfo_height()

            if cw < 2 or ch < 2:
                return

            h, w = frame_rgb.shape[:2]
            scale = min(cw / float(w), ch / float(h))
            nw, nh = int(w * scale), int(h * scale)

            resized = cv2.resize(
                frame_rgb,
                (nw, nh),
                interpolation=cv2.INTER_LINEAR
            )

            img = Image.fromarray(resized)
            photo = ImageTk.PhotoImage(image=img)

            self.canvas.delete("all")
            self.canvas.create_image(
                cw // 2, ch // 2,
                image=photo,
                anchor=tk.CENTER
            )
            self.canvas._photo = photo

            self._fps_count += 1
            now = time.time()
            elapsed = now - self._fps_time

            if elapsed >= 1.0:
                fps = self._fps_count / elapsed
                self.fps_lbl.config(text="FPS: {:.1f}".format(fps))
                self._fps_count = 0
                self._fps_time = now

        except Exception:
            pass

    def _on_close(self):
        self._disconnect()

        if self._serial_conn and self._serial_conn.is_open:
            try:
                self._serial_conn.close()
            except Exception:
                pass

        self.after(200, self.quit)
        self.after(250, self.destroy)


# ── Monkey-patches ────────────────────────────────────────────────────────────

def _patch_vision_for_gui():
    try:
        from vision import PepperVision
        from pepper_cam_reader import NaoCamera

        def run_headless(self):
            try:
                self.camera = NaoCamera(
                    ip=self.robot_ip,
                    port=self.port,
                    camera_index=self.camera_index,
                    resolution=VIDEO_RESOLUTION,
                    frame_rate=VIDEO_FPS
                )

                self._running = True

                while self._running:
                    frame = self.camera.get_frame()

                    if frame is None:
                        time.sleep(0.005)
                        continue

                    try:
                        self.frame_store.push_frame(frame)
                    except Exception:
                        pass

            except Exception as e:
                pass

            finally:
                self.stop()

        def stop_patched(self):
            self._running = False

            if getattr(self, "camera", None) is not None:
                try:
                    self.camera.release_camera()
                except Exception:
                    pass


        def switch_camera(self, index):
            self.camera_index = index

            if getattr(self, "camera", None) is not None:
                try:
                    self.camera.release_camera()
                except Exception:
                    pass

            self.camera = NaoCamera(
                ip=self.robot_ip,
                port=self.port,
                camera_index=index,
                resolution=VIDEO_RESOLUTION,
                frame_rate=VIDEO_FPS
            )

        PepperVision.run_headless = run_headless
        PepperVision.stop = stop_patched
        PepperVision.switch_camera = switch_camera

        _orig_init = PepperVision.__init__

        def new_init(self, robot_ip, port=9559, camera_index=1,
                     window_name="Pepper Camera", frame_store=None):
            _orig_init(self, robot_ip, port, camera_index, window_name)
            self.frame_store = frame_store
            self._running = False

        PepperVision.__init__ = new_init

    except ImportError:
        pass


def _patch_tracker_for_gui():
    try:
        from tracking import PepperHeadTracker
        import socket as _socket

        def run_patched(self):
            try:
                self.setup_socket()
                while getattr(self, "tracking_enabled", True):
                    try:
                        data, addr = self.sock.recvfrom(1024)
                        message = data.decode("utf-8")
                        parts = message.split(",")

                        if len(parts) >= 2:
                            self.move_head(parts[0], parts[1])

                    except _socket.timeout:
                        continue

            except Exception as e:
                pass

            finally:
                try:
                    if self.sock:
                        self.sock.close()
                except Exception:
                    pass

        def stop_patched_tracker(self):
            self.tracking_enabled = False
            try:
                if getattr(self, "sock", None):
                    self.sock.close()
            except Exception:
                pass
            # ── NE PAS oublier le serveur Choregraphe ──
            self.stop_choreo_server()

        PepperHeadTracker.run = run_patched
        PepperHeadTracker.stop = stop_patched_tracker

    except ImportError:
        pass


if __name__ == "__main__":
    _patch_vision_for_gui()
    _patch_tracker_for_gui()

    app = PepperGUI()

    try:
        app.mainloop()
    except KeyboardInterrupt:
        try:
            app._on_close()
        except Exception:
            try:
                app.destroy()
            except Exception:
                pass