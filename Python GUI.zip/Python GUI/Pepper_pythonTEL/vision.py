# -*- coding: utf-8 -*-
import cv2
from pepper_cam_reader import NaoCamera


class PepperVision(object):
    def __init__(self, robot_ip, port=9559, camera_index=1, window_name="Pepper Camera"):
        self.robot_ip = robot_ip
        self.port = port
        self.camera_index = camera_index
        self.window_name = window_name
        self.camera = None
        self.fullscreen = False

    def toggle_fullscreen(self):
        self.fullscreen = not self.fullscreen

        mode = cv2.WINDOW_FULLSCREEN if self.fullscreen else cv2.WINDOW_NORMAL

        cv2.setWindowProperty(
            self.window_name,
            cv2.WND_PROP_FULLSCREEN,
            mode
        )

    def run(self):
        try:
            self.camera = NaoCamera(
                ip=self.robot_ip,
                port=self.port,
                camera_index=self.camera_index
            )

            cv2.namedWindow(self.window_name, cv2.WINDOW_NORMAL)

            print("Camera started.")
            print("Press F to toggle fullscreen.")
            print("Press Q or ESC to quit.")

            while True:
                frame = self.camera.get_frame()

                if frame is None:
                    continue

                cv2.imshow(self.window_name, frame)

                key = cv2.waitKey(1) & 0xFF

                if key == ord('f'):
                    self.toggle_fullscreen()

                elif key == ord('q') or key == 27:
                    break

        except Exception as e:
            print("[VISION ERROR]: {}".format(e))

        finally:
            self.stop()

    def stop(self):
        if self.camera is not None:
            self.camera.release_camera()

        cv2.destroyAllWindows()
        print("Camera stopped.")